## Informations administratives

Cette page rassemble les informations pratiques à connaître avant d'aborder les chapitres techniques.

- L'émargement est réalisé deux fois par journée de formation.
- Les besoins et attentes sont recueillis au démarrage de la session.
- Les accès temporaires et les consignes propres aux labs sont communiqués pendant la session et ne sont pas publiés dans ce support.

## Horaires

| Période | Matin | Après-midi |
|---|---:|---:|
| Lundi | 9 h 30 – 12 h 30 | 13 h 30 – 17 h 30 |
| Mardi à vendredi | 9 h 00 – 12 h 30 | 13 h 45 – 17 h 00 |

Une pause de 15 minutes est prévue le matin et l'après-midi.

## Tour de table

Avant d'aborder les concepts techniques, ce tour de table permet d'adapter les exemples et le niveau d'accompagnement au contexte professionnel du groupe :

- Quel est votre métier et votre environnement technique actuel ?
- Avez-vous déjà utilisé un cloud public ou administré une infrastructure virtualisée ?
- Quels services ou sujets AWS rencontrez-vous dans vos projets ?
- Quel objectif professionnel souhaitez-vous atteindre avec cette formation ?
- Existe-t-il une contrainte particulière à prendre en compte : sécurité, réseau, coûts, exploitation ou architecture ?

Les réponses servent à choisir les exemples et le niveau d'approfondissement sans modifier la couverture du programme.

> [!important]
> **Règle d'or de cette formation :** interrompre le formateur dès qu'une notion n'est pas comprise ou qu'une question se présente ; partager son écran en cas de blocage technique afin de permettre un diagnostic collectif ; participer activement aux échanges et aux validations.

## Finalité de la formation

La formation apporte les bases nécessaires pour analyser une architecture AWS, comprendre les responsabilités de sécurité, sélectionner les principaux services de calcul, de stockage, de réseau et de données, puis introduire l'automatisation et la supervision.

Le support sépare volontairement trois activités :

- le **cours**, consacré aux concepts, au fonctionnement des services et aux décisions d'architecture ;
- les **travaux pratiques**, réalisés dans l'environnement temporaire remis au début de la formation ;
- les **quiz**, utilisés pour vérifier immédiatement la compréhension de chaque chapitre.

## Objectifs de la formation

À l'issue de la formation, vous saurez :

- **expliquer** les fondamentaux du Cloud Computing et le modèle de responsabilité partagée pour choisir une région ou une architecture multi-AZ adaptée ;
- **concevoir** une gestion des identités et des accès sécurisée avec IAM (rôles temporaires, moindre privilège, MFA, traçabilité) ;
- **concevoir** un VPC segmenté et choisir un service de données (relationnel, NoSQL ou cache) adapté à un besoin donné ;
- **sélectionner et configurer** les services de calcul et de stockage adaptés (EC2, Lambda, S3, EBS, EFS) en tenant compte de l'élasticité, de la disponibilité et de la reprise d'activité ;
- **automatiser** une infrastructure avec CloudFormation, l'administrer avec Systems Manager et l'évaluer avec CloudWatch et les six piliers du AWS Well-Architected Framework.

## Public et prérequis

Le parcours s'adresse aux professionnels de l'informatique, de l'exploitation, du développement, de la sécurité ou de l'architecture qui souhaitent comprendre ou consolider leur pratique d'AWS.

Les manipulations nécessitent :

- un ordinateur disposant d'un navigateur web récent ;
- une connexion Internet stable ;
- l'accès aux environnements temporaires remis en début de formation.

Aucun compte AWS personnel, aucune carte bancaire et aucune installation locale de la CLI AWS ne sont exigés pour suivre les activités prévues.

## Méthode de travail

1. Lire les objectifs du chapitre.
2. Parcourir les concepts dans l'ordre proposé ou accéder directement à une notion précise.
3. Consulter le glossaire et la cheat sheet depuis les liens du chapitre.
4. Réaliser les modules et labs indiqués dans l'environnement de formation.
5. Terminer par le quiz interactif du chapitre.
